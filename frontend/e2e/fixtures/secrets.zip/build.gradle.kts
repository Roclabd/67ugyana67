// Identifies the synthetic Gradle project root.
